# Machine Learning project #
library(dplyr) # or library("tidyverse")
install.packages("MASS")
library(MASS)
install.packages("pracma")
library(pracma)
set.seed(8623987)

target2 <- MLProjectData %>% 
  mutate(target = as.numeric(target)) %>% 
  arrange(target, desc(target)) %>% 
  mutate(target_norm = xx_target) %>%
  mutate(log_target = log(target)) %>% 
  mutate(scale_target = scale(target)) %>%
  #mutate(scale_log_target = scale(log(target))) %>%
  #select(id, target, log_target, scale_target)
target$scale_log_target = scale(target$log_target)

scatter.smooth(x=target$id, y=target$target, main="id ~ target")  # scatterplot
hist(target$target)
scatter.smooth(x=target$id, y=target$scale_log_target, main="id ~ target")  # scatterplot
hist(target$log_target)
hist(target$scale_target)
hist(target$scale_log_target)

library(MASS)

# generate some data
set.seed(1)
#n <- 100
x <- target$id
y <- target$scale_log_target

# run a linear model
m <- lm(y ~ x)

# run the box-cox transformation
bc <- boxcox(y ~ x)

(lambda <- bc$x[which.max(bc$y)])
#[1] 0.4242424

powerTransform <- function(y, lambda1, lambda2 = NULL, method = "boxcox") {
  
  boxcoxTrans <- function(x, lam1, lam2 = NULL) {
    
    # if we set lambda2 to zero, it becomes the one parameter transformation
    lam2 <- ifelse(is.null(lam2), 0, lam2)
    
    if (lam1 == 0L) {
      log(y + lam2)
    } else {
      (((y + lam2)^lam1) - 1) / lam1
    }
  }
  
  switch(method
         , boxcox = boxcoxTrans(y, lambda1, lambda2)
         , tukey = y^lambda1
  )
}


# re-run with transformation
mnew <- lm(powerTransform(y, lambda) ~ x)

# QQ-plot
op <- par(pty = "s", mfrow = 1) #c(1, 2))
qqnorm(m$residuals); qqline(m$residuals)
qqnorm(mnew$residuals); qqline(mnew$residuals)
par(op)
par(mfrow=c(1,1))


library(dplyr) # or library("tidyverse")
#install.packages("MASS")
library(MASS)
#install.packages("LambertW")
library(LambertW)

target <- MLProjectData %>% 
  mutate(as.numeric(target)) %>% 
  arrange(target, desc(target)) %>% 
  mutate(id = row_number()) %>%
  mutate(log_target = log(target)) %>% 
  mutate(scale_target = scale(target)) 

set.seed(1)

##### example ####
theta.tmp <- list(beta = c(2000, 400), delta = 0.2)
yy <- rLambertW(n = 100, distname = "normal", 
                theta = theta.tmp)
test_norm(yy)
mod.Lh <- MLE_LambertW(yy, distname = "normal", type = "h")
summary(mod.Lh)
xx <- get_input(mod.Lh)
test_norm(xx)

##### Target Data #####
test_norm(target$target)
hist(target$target)
mod.target <- MLE_LambertW(target$target, distname = "normal", type = "h")
summary(mod.target)
xx_target <- get_input(mod.target)
test_norm(xx_target)

qqnorm(xx_target)
hist(xx_target)

scatter.smooth(x=xx_target, y=target$target, main="id ~ target")  # scatterplot

MLProjectData$target_norm = xx_target

target$lambert_target = lambertWp(target$target)
xyz = (target$target)
low = quantile(xyz, .25)
high = quantile(xyz, .75)

xl = MLProjectData[MLProjectData$target <= low, ] 
xh = MLProjectData[MLProjectData$target >= high, ] 
xmid = MLProjectData[MLProjectData$target >= low & MLProjectData$target <= high, ] 
ymid = xmid[sample(nrow(xmid), 1589), ]
newa = dplyr::bind_rows(xl, xh)
test_norm(newa$target)
hist(newa$target)
qqnorm(newa$target)
qqline(newa$target)

newa$lamb_tar = lambertWp(newa$target)

final_table = dplyr::bind_rows(newa, ymid)
qqnorm(final_table$target)
test_norm(final_table$target)
hist(final_table$target)
final_table$lamp_target = lambertWp(final_table$target)
qqnorm(final_table$lamp_target)
test_norm(final_table$lamp_target)
hist(final_table$lamp_target)



target$unlambert_target = target$lambert_target*exp(target$lambert_target)

limit(LambertW(-1/r*y*exp(y)), y=-infinity) = 0
drop.col = c(target, target_norm, as.numeric(target), btn_target, unlambert_target)
target2 = target %>% select(-c(target, target_norm, as.numeric(target), btn_target, unlambert_target))

target2 <- MLProjectData %>% 
  mutate(target = as.numeric(target)) %>% 
  arrange(target, desc(target)) %>%
  mutate(target_norm = lambertWp(target)) %>%
  mutate(target_norm_2 = lambertWp(target_norm)) %>%
  mutate(target_norm_std = scale(target_norm_2))
  

xl = MLProjectData[MLProjectData$target <= low, ] 
xh = MLProjectData[MLProjectData$target >= high, ] 
xmid = MLProjectData[MLProjectData$target >= low & MLProjectData$target <= high, ] 
ymid = xmid[sample(nrow(xmid), 1589), ]
newa = dplyr::bind_rows(xl, xh)
test_norm(newa$target)
hist(newa$target)
qqnorm(newa$target)
qqline(newa$target)

hist(MLProjectData$target)
qqnorm(MLProjectData$target)
qqline(MLProjectData$target)


newa
write.csv(target2, file = "/Users/johnpamplin/Documents/RStudio/target2.csv")
write.csv(final_table, file = "/Users/johnpamplin/Documents/RStudio/final_table.csv")
write.csv(newa, file = "/Users/johnpamplin/Documents/RStudio/newa.csv")

test_data = read.csv(file = "/Users/johnpamplin/Documents/RStudio/testData.csv")

low2 = quantile(xyz, .15)
high2 = quantile(xyz, .85)

xl2 = MLProjectData[MLProjectData$target <= low2, ] 
xh2 = MLProjectData[MLProjectData$target >= high2, ] 
xmid2 = MLProjectData[MLProjectData$target >= low2 & MLProjectData$target <= high2, ] 
ymid2 = xmid2[sample(nrow(xmid2), 955), ]
newa2 = dplyr::bind_rows(xl2, xh2)
final_table = dplyr::bind_rows(newa2, ymid2)
qqnorm(final_table$target)
qqline(MLProjectData$target)
hist(final_table$target)

hist(MLProjectData$target)
qqnorm(MLProjectData$target)
qqline(MLProjectData$target)
